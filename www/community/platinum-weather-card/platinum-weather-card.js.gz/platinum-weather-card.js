export{P as PlatinumWeatherCard}from"./platinum-weather-card-e93fe9db.js";
