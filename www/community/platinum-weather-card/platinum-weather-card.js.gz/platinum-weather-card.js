export{P as PlatinumWeatherCard}from"./platinum-weather-card-81a3460e.js";
