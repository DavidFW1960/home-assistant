export{P as PlatinumWeatherCard}from"./platinum-weather-card-a24fb50b.js";
