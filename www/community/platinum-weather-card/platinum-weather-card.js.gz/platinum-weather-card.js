export{W as WeatherCard}from"./platinum-weather-card-a88ca3e4.js";
