export{W as WeatherCard}from"./platinum-weather-card-cb8d527e.js";
