export{P as PlatinumWeatherCard}from"./platinum-weather-card-45789b2b.js";
