export{P as PlatinumWeatherCard}from"./platinum-weather-card-52c96873.js";
